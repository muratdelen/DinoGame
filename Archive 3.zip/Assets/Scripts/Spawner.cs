using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    [System.Serializable]
    public struct SpawnableObject {
        public GameObject prefab;
        [Range(0f, 1f)]
        public float spawnChange;
    }
    public SpawnableObject[] objects;

    public float minSpawnRate = 1f;
    public float maxSpawnRate = 2f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnEnable()
    {
        Invoke(nameof(Spawn), Random.Range(minSpawnRate, maxSpawnRate));
    }
    private void OnDisable()
    {
        CancelInvoke();
    }
    //created object by the function
    private void Spawn()
    {
        float spawnChange = Random.value;
        foreach(var obj in objects)
        {
            if(spawnChange < obj.spawnChange)
            {
                GameObject objtacle = Instantiate(obj.prefab);
                objtacle.transform.position += transform.position;
                break;
            }

            spawnChange -= obj.spawnChange;
        }
        Invoke(nameof(Spawn), Random.Range(minSpawnRate, maxSpawnRate));
    }
}
